# Codex HUD Tree / Workbench 改进补丁

基线：`CartmanFatass/codex-hud` 的 main，完整 commit 为 `8c3dcc21d6d5bf0daae0f7ffb2450290f98889f1`。

通过 GitHub connector 读取并确认该版本。此交付物不是新的 commit，也没有修改远端或你的本地 checkout。容器内只有用于制作补丁的源文件副本。四个被修改的原文件都已核对 Git blob SHA，记录在 `BASE_MANIFEST.json`。

## 改动

### 子代理：把“任务和证据”放在首位

Agents 在内容宽度至少 16 列、正文高度至少 4 行时使用两行卡片：第一行保留名称、状态、模型/effort glyph 和后代徽标；第二行使用已有 taskText 清洗后的任务。极窄或极矮时回到单行，不增加 rollout 扫描。

Details 先显示明确状态和任务，再显示最近工具的实际 cmd/command 与明确结果。大段 inline code 默认只显示工具名与 inline code 提示，v 展开后再看代码/输出。没有明确成功证据时显示 result unknown，不能把 completed 当成测试通过。上一 turn 的工具标记 prior turn，不冒充本轮动作。只有 turnStartedAt 可以标为 This turn；创建时间不再冒充本轮开始。Last evidence 与运行状态分开，安静不等于卡死。

模型、effort、完整 UUID、输出速率等仍可查看，但不再挤占 Details 最前面的任务和动作信息。任务/计划只使用已有 rollout 数据，没有新增推测进度、测试成功率或文件归属。

### Changes：按真实内容宽度降级

内容宽度小于 36 列（即带边框和留白时 pane 宽度小于 40 列）只显示 workspace 摘要。默认 16/20/30 列均不会列出文件和逐行 diff。摘要展示文件总数、staged、unstaged、untracked，冲突和部分读取失败优先。

摘要模式的鼠标不选择不存在的文件行，j/k 只滚动摘要，Enter 进入工作区概览。它不会悄悄移动一个不可见的 selectedFile。

45 列开始显示固定 XY 状态列和文件列，用点明确表示空状态。长路径优先保留 basename 和最近一段目录，完整路径与 rename 的来源路径放在 Details。行增删数只在内容宽度至少 52 列时作为对齐的末列出现；较窄时去 Details 查看选中文件的统计。二进制不伪装为 0 行。统计注明 index + worktree，不冒充净 HEAD diff。

70 列起改为左列 Agents/Activity，右列 Details/Changes；两列间留一个空列，让文件区不再被压到原来约 26 列的左栏。默认高 24 行时，空间预算优先保证 Details 能呈现任务、最新命令及结果，而不是四格平均分配。

Details 内容不够宽时不显示 diff；树进程也不会为不可见或过窄的 diff 触发新的 readGitDiff。宽 diff 每条源代码行只占一条屏幕行，超长行显式省略，不软换行造成视觉混乱。

### 留白与点击一致

每个正常大小的 pane 内容区左右各留 1 列。渲染与输入共用 rowItems/paneItemAt：身份行和任务行映射回同一逻辑 agent；边框、内边距、空行、摘要和警告行不触发 agent 切换。PageDown 按逻辑 agent 数而不是卡片文本行数移动。选中身份依然由原来的 UUID 状态维护。

safeText 将 tab、换行、ANSI/C1 控制符和双向文字控制符显示为转义文本。文件名进入多行详情之前先转义，防止文件名里的换行伪造新的界面行。

## 未改动的边界

没有修改 bin/codex-hud、bin/codex-hud-toggle、bin/codex-hud-paste、src/index.ts、session-navigation、parent 解析、collector 或 settings。

因此此补丁没有添加 tmux 键绑定、Ctrl+T 绑定、焦点操作、Git 写操作或新的会话切换协议。tree-page 只调整了卡片点击命中、是否需要读取 diff 和 resize 后刷新检查。真正的会话切换仍调用原 navigateSession，仍只有 o 或有效 agent 点击触发；UUID 校验和 composer/picker 安全门没有改动。

这不是对原版本全部产品约束的端到端认证。F12/Shift+F12、Codex 0.154 picker、草稿/copy-mode、终端鼠标和右键粘贴仍需在真实环境回归。

## 应用

先确认位于指定基线的仓库根目录。保留自己的未提交改动，不必 staging，也不要 checkout。

```sh
git apply --check /path/to/codex-hud-workbench-8c3dcc2.patch
git apply /path/to/codex-hud-workbench-8c3dcc2.patch
npm run build
npm test
```

不要加 --index 或 --3way。若 --check 报冲突，停止并检查相应 diff；不要用整文件覆盖自己的工作区改动。

补丁只包含 6 个文件。`changed-files/` 是修改后文件的参考副本，不是完整仓库。编译产物未打包。

## 验证范围

见 `TEST_RESULTS.md`。已经实际运行 14 个独立的布局/证据函数测试及 6 个 TS 文件的语法转译检查。补丁在 blob SHA 校验后的源文件副本上通过 git apply --check；应用到另一份无 Git index 的副本后，逐文件字节比对一致。

未运行完整 npm run build、完整 npm test 或 tmux/Codex 联调。已有 workbench 测试作了针对行为变化的调整，并新增 6 个渲染/交互回归用例，但这些依赖完整仓库的测试尚未执行。不能把这次隔离单测结果当成整个 HUD 测试成功率。
