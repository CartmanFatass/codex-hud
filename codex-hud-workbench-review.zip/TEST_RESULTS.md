# 实际验证记录

## 已执行

- Node v22.16.0 的 node --test 执行 workbench-layout.test：14 个测试，14 个通过，0 个失败。原始 TAP 见 isolated-tests.tap。
- 几何测试覆盖窄/宽/极矮窗口、4 个 focus、16 种折叠组合及 zoom；独立断言 pane 不越界、不重叠。
- 其他隔离测试验证左右留白、两行卡片映射、空白不可选、滚动后的命中、PageDown 逻辑项数、窄栏不请求 diff、Git 分类重叠/冲突/部分失败、工具结果证据和 inline code 降级。
- 使用本环境 TypeScript 的 transpileModule 对所有 6 个改动/新增 TS 文件进行了语法检查，无语法诊断。原始输出见 syntax-check.txt。这不是完整类型检查。
- 四个原文件的 Git blob SHA 与 GitHub connector 返回值一致。
- git apply --check 在上述经过校验的源文件副本上退出码为 0。
- 将补丁应用到另一份无 Git index 的验证副本，6 个修改后文件与交付源码逐字节一致。

## 没有执行

本环境没有用户的实际 checkout、完整依赖或 tmux/Codex 运行实例；尝试取得公开源码归档也未成功。因此没有运行完整 npm build/test，没有连接真实 rollout/picker，也没有交互式终端验收。

新增的 6 个完整渲染/交互回归用例已写入 workbench.test.ts，但未在完整项目执行：窄栏只预览工作区、两行 agent 点击、部分 Git 失败、特殊文件名、pane 留白/列间隙、窄详情不显示 diff。

原有测试中，文件导航场景从 32 列调整到 45 列，因为 32 列现在有意只显示摘要；紧凑 agent Details 的行数上限调整为 12 行，且错误结果放在工具名之前。其余原有断言保留。

## 建议在真实环境验收的内容

在 16、20、30、45、70 列下检查名字、任务、Details 和 Changes。F12 不抢 Codex 焦点；Shift+F12 聚焦树；Ctrl+T 仍属于 Codex；点击任务续行只切换该 agent，点击空白/底栏不抢焦点。验证草稿、copy-mode、未知界面和截断 UUID 不发键；目标可见时合并移动，Enter 前仍核全 UUID，切换后不重开 picker。验证滚动、右键/中键粘贴以及非 ASCII、换行、tab、ANSI 文件名。验证 Git 读取失败不被显示为 clean。
