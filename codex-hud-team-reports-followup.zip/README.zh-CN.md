# Codex HUD：全员汇报与切换闪烁复核

## 基线与应用范围

GitHub main 核对为 `8c3dcc21d6d5bf0daae0f7ffb2450290f98889f1`。
主补丁是**接在上轮 codex-hud-workbench-8c3dcc2.patch 后面的增量补丁**，不是对原始 main 的替代补丁。
看不到用户本地额外修改；请先在完整仓库执行 `git apply --check`。冲突时停止，不使用覆盖、reset、checkout 或 staging。
本次没有修改远端，没有提交或暂存。源码改动仅在临时容器副本及补丁中。

## 主补丁内容

- 默认 Details 变成 Reports：所有子代理的已有状态 + 最新公开汇报，不随 selectedId 过滤。
- 沿用兄弟节点排序，公开汇报/token/log 的更新时间不会参与排序。树折叠和过滤不会隐藏 Reports 中其他 agent。
- 汇报来自 `event_msg.agent_message` 或公开的 `response_item` assistant 文本。排除 analysis/reasoning、工具输出、token 和 plan 事件。
- 仅保留最新消息摘录（最多 600 个 Unicode code points，超出用省略号），不做模型生成的摘要。
- 统一标记为 agent 自述/未核验。回答文本不能推出成功率、任务进度、工作区文件归属或 running 状态。
- 上一轮汇报标记 Prev；无公开汇报明确显示 No public report yet。unknown 不提升为 running。
- 通过现有 subagent-tree 增量扫描为每个后代收集 lastReport，非仅加载点选 agent。
- 工具、plan 和输出保留在显式 Inspector；Enter / v 打开，Esc 返回全员汇报。点击 agent 仍走原来的会话切换，不打开单人 Inspector。
- 默认全员视图不再触发选中 rollout 的工具解析；Inspector 打开后才按需解析。
- 同一 agent 的 400ms 内重复鼠标事件去重；不把“上次点了谁”缓存成当前 Codex UUID。原导航的并发锁及 picker 核验保留。

## 鼠标焦点补丁（单独、可选）

`codex-hud-mouse-focus-optional.patch` 只改变树 pane 的普通左键路由：使用现有 wheel 相同形式的 `send-keys -t= -M`，不先 select-pane 到树。
底栏、Codex 本身以及其他 pane 的原处理保留。F12 / Shift+F12 / Ctrl+T / 右键粘贴的绑定不改。
这减少“Codex → Tree → Codex”的额外焦点往返，但没有实机 tmux 验证，建议单独试用。
现有 tmux 绑定不会因 TypeScript build 或 F12 开关自动重装；在新的 HUD 会话里验证入口脚本安装的绑定，不要为测试强制关闭仍在工作的 Codex 会话。

## 已确认的闪烁机制

核对 OpenAI Codex `rust-v0.154.0` 的 `codex-rs/tui/src/app/session_lifecycle.rs`：

`select_agent_thread → render_thread_snapshot → reset_for_thread_switch → clear_terminal_for_thread_switch → clear_scrollback_and_visible_screen_ansi`。
之后重放目标会话 snapshot。HUD 不能仅靠降低 refreshMs 消除这条 Codex 清屏路径。
此外，原 HUD MouseDown1Pane 对树先 select-pane，而 navigateSession 结束再 focus main；focus-events 也开启。
原 navigateSession 已合并可见目标的 Up/Down、Enter 前复核完整 UUID、提交后不重开 picker；这些不是本次新增修复。
未获取用户终端录制，不能声称清屏是其设备上所有闪烁的唯一来源，也不能承诺零闪烁。

## 应用主补丁

在完整仓库根目录：

```bash
git apply --check /path/to/codex-hud-team-reports-followup.patch
git apply /path/to/codex-hud-team-reports-followup.patch
npm run build
npm test
```

鼠标补丁需单独 check / apply。不提供 staging、commit、checkout 命令。
关闭并重开右侧 pane 可启动重新构建的树进程；这不等于重装 tmux 鼠标绑定。

## 验证边界

实际运行：

- 新增公开汇报解析器 6 个 Node 单测：6 pass、0 fail。
- 6 个 TS 文件的 transpileModule 语法转译：0 diagnostics。不是项目级类型检查。
- 基于上轮完整交付文件的 6 文件部分通过 git apply --check，在临时副本应用后逐字节相同。
- 两个补丁通过 git apply --numstat 格式解析。
- 鼠标绑定片段通过 bash -n。

未运行：

- 完整仓库 git apply --check（当前容器没有完整 checkout；types.ts、subagent-tree.ts 的改动使用 connector 读取的准确上下文生成）。
- npm run build / 完整 npm test。
- 新增的 3 个 renderer/input 回归用例。
- Codex / tmux 实机切换、焦点与闪烁联调。

完整仓库测试可能揭示仍需修订的类型、布局或交互问题；本补丁不是已联调验收的发布。
