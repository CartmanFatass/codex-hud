/** Default F12 view: a monitor, not another transcript. No I/O or terminal input here. */
import type { SubagentTree, SubagentTreeNode } from '../types.js';
import type { GitChanges } from '../collectors/git-changes.js';
import type { WorktreesSnapshot, WorktreeInfo } from '../collectors/worktrees.js';
import type { HudSettings } from '../settings.js';
import type { WorkbenchInput } from '../utils/workbench-input.js';
import { initialPanelState, reconcileSelection, visibleRows, applyKey, type PanelState } from './panel-state.js';
import { theme, colors, visualLength, truncateAnsi } from './colors.js';

export const MONITOR_PANES = ['agents', 'worktrees', 'changes', 'details'] as const;
export type MonitorPane = typeof MONITOR_PANES[number];
export type PaneMode = 'open' | 'folded' | 'closed';
export type MonitorModes = Record<MonitorPane, PaneMode>;
export interface MonitorState {
  tree: PanelState;
  focus: MonitorPane;
  modes: MonitorModes;
  scroll: Record<MonitorPane, number>;
  selectedWorktree: string | null;
  selectedFile: string | null;
  preview: 'agent' | 'worktree' | 'file';
  help: boolean;
  zoom: boolean;
}
export interface MonitorRow { text: string; item?: string }
export interface MonitorRect {
  id: MonitorPane;
  x: number; y: number; width: number; height: number;
  offset: number;
  contentLength: number;
  rows: MonitorRow[];
}
export interface MonitorControl {
  kind: 'main' | 'settings' | 'fold' | 'close';
  pane?: MonitorPane;
  x: number; y: number; width: number;
}
export interface MonitorFrame { lines: string[]; panes: MonitorRect[]; controls: MonitorControl[]; state: MonitorState }
export interface MonitorData {
  tree: SubagentTree;
  state: MonitorState;
  width: number; height: number;
  git?: GitChanges | null;
  worktrees?: WorktreesSnapshot | null;
  diff?: string[];
  nowMs?: number;
  notice?: string | null;
  error?: string | null;
}
export interface MonitorContext {
  tree: SubagentTree;
  git?: GitChanges | null;
  worktrees?: WorktreesSnapshot | null;
  frame?: MonitorFrame;
}
export interface MonitorOutcome {
  state: MonitorState;
  close: boolean;
  action?: {type:'settings'} | {type:'switch'; id:string};
}

export function initialMonitorState(): MonitorState {
  return {tree:{...initialPanelState(),sort:'active'}, focus:'agents',
    modes:{agents:'open',worktrees:'open',changes:'closed',details:'closed'},
    scroll:{agents:0,worktrees:0,changes:0,details:0}, selectedWorktree:null,selectedFile:null,
    preview:'agent',help:false,zoom:false};
}
export function monitorModes(settings: HudSettings): MonitorModes {
  return {agents:settings.agentsPane, worktrees:settings.worktreesPane, changes:settings.changesPane, details:settings.detailsPane};
}
export function monitorPreferences(state: MonitorState): Partial<HudSettings> {
  return {agentsPane:state.modes.agents, worktreesPane:state.modes.worktrees,
    changesPane:state.modes.changes, detailsPane:state.modes.details};
}
export function reconcileMonitor(state: MonitorState, tree: SubagentTree, git?: GitChanges | null, worktrees?: WorktreesSnapshot | null): MonitorState {
  const rows = visibleRows(tree.nodes, state.tree);
  const selected = reconcileSelection(state.tree, tree.nodes, rows);
  const entries = worktrees?.entries ?? [];
  const selectedWorktree = entries.some(w => w.path === state.selectedWorktree) ? state.selectedWorktree
    : entries.find(w => !w.bare && w.prunable === undefined)?.path ?? entries[0]?.path ?? null;
  const selectedFile = git?.files.some(f => f.path === state.selectedFile) ? state.selectedFile : git?.files[0]?.path ?? null;
  const focus = state.modes[state.focus] !== 'closed' ? state.focus : MONITOR_PANES.find(id => state.modes[id] !== 'closed') ?? 'agents';
  const changed = selected.selectedId !== state.tree.selectedId || selectedWorktree !== state.selectedWorktree || selectedFile !== state.selectedFile;
  return {...state, tree:selected, selectedWorktree, selectedFile, focus,
    scroll:{...state.scroll,details:changed ? 0 : state.scroll.details}};
}

/** External strings are escaped before width calculation or painting. */
export function monitorText(text: string): string {
  return text.replace(/[\x00-\x1f\x7f-\x9f\u202a-\u202e\u2066-\u2069]/g, ch => {
    const cp = ch.charCodeAt(0);
    return ch === '\n' ? '\\n' : ch === '\r' ? '\\r' : ch === '\t' ? '\\t'
      : cp > 255 ? `\\u${cp.toString(16).padStart(4,'0')}` : `\\x${cp.toString(16).padStart(2,'0')}`;
  });
}
function fit(text: string, width: number): string {
  const clipped = truncateAnsi(text, Math.max(0,width));
  return clipped + ' '.repeat(Math.max(0,width-visualLength(clipped)));
}
function pair(left: string, right: string, width: number): string {
  if (!right) return truncateAnsi(left,width);
  const rightWidth = visualLength(right);
  if (rightWidth >= width) return truncateAnsi(right,width);
  return fit(left,width-rightWidth-1)+' '+right;
}
function wrapped(text: string, width: number): string[] {
  if (width < 1) return [];
  const lines: string[] = []; let line = '';
  for (const char of monitorText(text)) {
    if (visualLength(line+char) > width && line) { lines.push(line); line=''; }
    line += char;
  }
  lines.push(line);
  return lines.map(s => truncateAnsi(s,width));
}
function age(at: Date | undefined, now: number): string {
  if (!at || !Number.isFinite(at.getTime())) return '?';
  const seconds = Math.max(0, Math.floor((now-at.getTime())/1000));
  return seconds < 60 ? `${seconds}s` : seconds < 3600 ? `${Math.floor(seconds/60)}m` : `${Math.floor(seconds/3600)}h`;
}
function nodeStatus(node: SubagentTreeNode, now: number): {icon:string; label:string; paint:(s:string)=>string} {
  switch (node.status) {
    case 'running': return {icon:'▸',label:node.turnStartedAt ? age(node.turnStartedAt,now) : 'run',paint:theme.info};
    case 'starting': return {icon:'·',label:'start',paint:theme.info};
    case 'completed': return {icon:'✓',label:'done',paint:theme.success};
    case 'error': return {icon:'!',label:'error',paint:theme.error};
    default: return {icon:'?',label:'unknown',paint:colors.dim};
  }
}
export function worktreeLabel(entry: WorktreeInfo, now: number): string {
  if (entry.bare) return 'bare';
  if (entry.prunable !== undefined) return 'prunable';
  if (entry.error) return 'unreadable';
  if (!entry.status || entry.observedAt === undefined) return '?';
  if (now-entry.observedAt > 30_000) return 'stale';
  if (entry.status.conflicts) return `!${entry.status.conflicts}`;
  return entry.status.changed ? `${entry.status.changed} mod` : 'clean';
}
function basename(path: string): string { return path.replace(/[\\/]+$/,'').split(/[\\/]/).at(-1) || path; }
function findNode(nodes: SubagentTreeNode[], id: string | null): SubagentTreeNode | undefined {
  for (const node of nodes) { if (node.id === id) return node; const found = findNode(node.children,id); if (found) return found; }
  return undefined;
}

function paneRows(id: MonitorPane, input: MonitorData, state: MonitorState, width: number, now: number): MonitorRow[] {
  if (id === 'agents') {
    const all = visibleRows(input.tree.nodes,{...state.tree,filter:'all',collapsed:new Set()});
    const totals = {run:0,done:0,error:0,unknown:0};
    for (const {node} of all) totals[node.status === 'running' || node.status === 'starting' ? 'run' : node.status === 'completed' ? 'done' : node.status === 'error' ? 'error' : 'unknown']++;
    const summary = width < 16
      ? [totals.error ? `!${totals.error}` : '', `${totals.run}▸`, `${totals.done}✓`, totals.unknown ? `?${totals.unknown}` : ''].filter(Boolean).join(' ')
      : [totals.error ? `!${totals.error}` : '', `${totals.run} run`, `${totals.done} done`, totals.unknown ? `?${totals.unknown}` : ''].filter(Boolean).join('  ');
    const result: MonitorRow[] = [{text:colors.dim(truncateAnsi(summary,width))}];
    for (const row of visibleRows(input.tree.nodes,state.tree)) {
      const status = nodeStatus(row.node,now);
      const branch = visualLength(row.prefix) > Math.floor(width/4) ? '… ' : row.prefix;
      const prefix = `${row.node.id === state.tree.selectedId ? '›' : ' '}${branch}${row.collapsed && row.hasChildren ? '+' : ''}${status.icon} `;
      // The status gets a fixed right-hand slot. No Task/Reply/tool text, even at wide widths.
      const model = width >= 42 && row.node.model ? ` · ${monitorText(row.node.model)}` : '';
      result.push({text:status.paint(pair(prefix+monitorText(row.node.name)+model,width < 16 ? '' : status.label,width)),item:row.node.id});
    }
    if (result.length === 1) result.push({text:colors.dim(all.length ? 'No matching agents' : 'No subagents')});
    return result;
  }
  if (id === 'worktrees') {
    const snapshot = input.worktrees;
    if (!snapshot) return [{text:colors.dim('Reading worktrees…')}];
    if (snapshot.error) return [{text:theme.warning('No readable repository')}, {text:colors.dim('Set worktreeRoot')}, ...wrapped(snapshot.error,width).map(text=>({text:colors.dim(text)}))];
    const rows: MonitorRow[] = [];
    if (snapshot.truncated) rows.push({text:theme.warning('Worktree list limited')});
    for (const entry of snapshot.entries) {
      const label = worktreeLabel(entry,now);
      const mark = entry.locked !== undefined ? 'L ' : entry.path === state.selectedWorktree ? '› ' : '  ';
      const name = monitorText(entry.branch ?? (entry.detached ? 'detached' : basename(entry.path)))
        + (width >= 40 ? ' · '+monitorText(entry.path) : '');
      const paint = label.startsWith('!') || entry.error ? theme.warning : label === 'clean' ? colors.dim : theme.value;
      rows.push({text:paint(pair(mark+name,label,width)),item:entry.path});
      // A directory label is useful identity, not a log line. Two lines only when it fits.
      if (width >= 20 && width < 40) rows.push({text:colors.dim(truncateAnsi('  '+monitorText(basename(entry.path)),width)),item:entry.path});
    }
    return rows.length ? rows : [{text:colors.dim('No worktrees recorded')}];
  }
  if (id === 'changes') {
    const git = input.git;
    const rows: MonitorRow[] = [];
    if (!git) return [{text:colors.dim('Reading selected worktree…')}];
    if (git.error) rows.push({text:theme.warning('Git incomplete')});
    if (!git.root) return [...rows,{text:colors.dim('No selected worktree')}];
    if (width < 36) {
      const changed = (x:string) => x !== ' ' && x !== '.' && x !== '?';
      const conflicts = git.files.filter(file=>file.conflict).length;
      return [...rows, ...(conflicts ? [{text:theme.warning(`! ${conflicts} conflicts`)}] : []), {text:colors.dim('Selected worktree')},
        {text:`${git.files.length} changed files`},
        {text:`${git.files.filter(f=>!f.conflict&&changed(f.index)).length} staged`},
        {text:`${git.files.filter(f=>!f.conflict&&changed(f.worktree)).length} unstaged`},
        {text:`${git.files.filter(f=>f.index==='?').length} untracked`}];
    }
    return [...rows, ...git.files.map(file => ({item:file.path,
      text:truncateAnsi(`${file.path===state.selectedFile?'›':' '} ${file.conflict?'!!':file.index+file.worktree} ${monitorText(file.path)}`,width)})),
      ...(git.files.length ? [] : [{text:colors.dim(git.error ? 'Status unknown' : 'Working tree clean')}])];
  }
  // Inspector is explicitly opened (Enter/v/4), never follows agent clicks into a transcript.
  let lines: string[] = [];
  if (state.preview === 'agent') {
    const node = findNode(input.tree.nodes,state.tree.selectedId);
    if (!node) lines = ['Select an agent'];
    else lines = [`${node.name} · ${node.status}`,node.model ?? 'Model unknown',node.effort ?? 'Effort unknown',
      `Turn start: ${node.turnStartedAt && Number.isFinite(node.turnStartedAt.getTime()) ? node.turnStartedAt.toISOString() : 'unknown'}`,`Last evidence: ${age(node.lastEventAt,now)}`,`UUID: ${node.id}`];
  } else if (state.preview === 'worktree') {
    const entry = input.worktrees?.entries.find(e=>e.path===state.selectedWorktree);
    if (!entry) lines = ['Select a worktree'];
    else {
      lines = [entry.path,`Branch: ${entry.branch ?? (entry.bare?'bare':'detached')}`,`HEAD: ${entry.head ?? '?'}`,`Status: ${worktreeLabel(entry,now)}`];
      if (entry.error) lines.push(entry.error);
      if (entry.locked !== undefined) lines.push(`Locked: ${entry.locked || 'yes'}`);
      if (entry.prunable !== undefined) lines.push(`Prunable: ${entry.prunable || 'yes'}`);
      if (entry.status) lines.push(`${entry.status.staged} staged / ${entry.status.unstaged} unstaged`,`${entry.status.untracked} untracked / ${entry.status.conflicts} conflicts`,
        `Ahead ${entry.status.ahead ?? '?'} / behind ${entry.status.behind ?? '?'}`);
      lines.push('Workspace status, not agent ownership');
    }
  } else {
    lines = [input.git?.root ?? 'No selected worktree', state.selectedFile ?? 'No selected file'];
    if (width < 36) lines.push('Widen for diff');
    else return [...lines.flatMap(t=>wrapped(t,width).map(text=>({text}))), ...(input.diff ?? ['Reading diff…']).map(t=>({text:truncateAnsi(monitorText(t),width)}))];
  }
  return lines.flatMap(line => wrapped(line,width).map(text=>({text})));
}

const TITLES: Record<MonitorPane,string> = {agents:'1 Agents',worktrees:'2 Worktrees',changes:'3 Changes',details:'4 Inspector'};
export function renderMonitor(input: MonitorData): MonitorFrame {
  const width = Math.max(0,Math.floor(input.width)); const height = Math.max(0,Math.floor(input.height));
  const state = reconcileMonitor(input.state,input.tree,input.git,input.worktrees);
  const frame: MonitorFrame = {lines:[],panes:[],controls:[],state};
  if (!width || !height) return frame;
  if (state.help) {
    const help = ['Monitor keys','1 Agents  2 Worktrees','3 Changes  4 Inspector','x close pane  - fold','1–4 reopen closed pane','Tab next visible pane','j/k preview  o switch','Click agent: switch','m return Main','Enter / v inspect','z zoom  Esc back','q close tree  , settings','done = turn completed','? = no status evidence','mod = changed files','L = locked worktree','stale = >30s since read'];
    frame.lines = help.slice(0,height).map(line=>truncateAnsi(line,width)); return frame;
  }
  const inner = Math.max(0,width-4); const now = input.nowMs ?? Date.now();
  const notice = input.notice || input.error;
  const noticeRows = notice && height >= 6 ? wrapped(notice,Math.max(1,width-2)).slice(0,2) : [];
  let budget = Math.max(0,height-2-noticeRows.length);
  const ids = MONITOR_PANES.filter(id=>state.modes[id] !== 'closed' && (!state.zoom || id===state.focus));
  const content = new Map(ids.map(id=>[id,paneRows(id,input,state,inner,now)]));
  // Header-only allocation first; small terminals never push another panel offscreen.
  const sizes = new Map<MonitorPane,number>();
  for (const id of ids) { sizes.set(id,budget>0?1:0); if (budget>0) budget--; }
  // Focused pane gets first chance, then round-robin: content-sized, not giant empty boxes.
  const order = [state.focus,...ids.filter(id=>id!==state.focus)].filter(id=>ids.includes(id));
  while (budget > 0) {
    let grew = false;
    for (const id of order) {
      if (!budget) break;
      const target = state.modes[id] === 'folded' ? 1 : Math.min(state.zoom ? height : id === 'details' ? 12 : 14,(content.get(id)?.length ?? 0)+2);
      const size = sizes.get(id) ?? 0;
      if (size && size < target) { sizes.set(id,size+1);budget--;grew=true; }
    }
    if (!grew) break;
  }
  frame.lines = Array.from({length:height},()=>fit('',width));
  frame.lines[0] = theme.accent(pair(width < 20 ? ' ← Main' : ' ← Main session','m ',width));
  frame.controls.push({kind:'main',x:0,y:0,width}); // Full-width, persistent hit target.
  let y = 1;
  for (const id of ids) {
    const h = sizes.get(id) ?? 0; if (!h) continue;
    const rows = content.get(id) ?? [];
    const count = Math.max(0,h-2);
    let offset = Math.max(0,Math.min(state.scroll[id],Math.max(0,rows.length-count)));
    const selected = id==='agents'?state.tree.selectedId:id==='worktrees'?state.selectedWorktree:id==='changes'&&inner>=36?state.selectedFile:null;
    const index = selected ? rows.findIndex(row=>row.item===selected) : -1;
    if (index>=0 && count) { if(index<offset)offset=index;else if(index>=offset+count)offset=index-count+1; }
    state.scroll[id]=offset;
    const pane = {id,x:0,y,width,height:h,rows,offset,contentLength:rows.length}; frame.panes.push(pane);
    const border = id===state.focus ? theme.accent : colors.dim;
    const buttons = width>=12 ? `[${state.modes[id]==='folded'?'+':'-'}][x]` : '';
    const shortTitle = {agents:'Agents',worktrees:width<20?'WT':'Worktrees',changes:'Changes',details:'Inspect'}[id];
    const title = fit(' '+(width<24 ? shortTitle : TITLES[id])+' ',Math.max(0,width-2-buttons.length));
    frame.lines[y] = truncateAnsi(border('┌'+title+buttons+'┐'),width);
    if(buttons) {
      frame.controls.push({kind:'fold',pane:id,x:width-7,y,width:3},{kind:'close',pane:id,x:width-4,y,width:3});
    }
    for(let i=0;i<count;i++) frame.lines[y+1+i]=truncateAnsi(border('│')+' '+fit(rows[offset+i]?.text ?? '',inner)+' '+border('│'),width);
    if(h>1) {
      const range=rows.length>count&&count?` ${offset+1}–${Math.min(rows.length,offset+count)}/${rows.length} `:'';
      frame.lines[y+h-1]=truncateAnsi(border('└'+fit(range,Math.max(0,width-2)).replace(/ /g,'─')+'┘'),width);
    }
    y+=h;
  }
  for(let i=0;i<noticeRows.length;i++) frame.lines[height-1-noticeRows.length+i]=theme.warning(fit(noticeRows[i],width));
  if(height>1) {
    frame.lines[height-1]=colors.dim(truncateAnsi(width<30 ? ' , Settings  1–4' : ' , Settings   1–4 reopen   ? keys',width));
    frame.controls.push({kind:'settings',x:0,y:height-1,width:Math.min(width,12)});
  }
  return frame;
}

function openPane(state: MonitorState, id: MonitorPane): MonitorState {
  const preview = id==='agents'?'agent':id==='worktrees'?'worktree':id==='changes'?'file':state.preview;
  return {...state,focus:id,preview,modes:{...state.modes,[id]:'open'},scroll:{...state.scroll,details:preview===state.preview?state.scroll.details:0}};
}
export function monitorItemAt(pane: MonitorRect, x: number, y: number): string | undefined {
  if(x<pane.x+2 || x>=pane.x+pane.width-2 || y<=pane.y || y>=pane.y+pane.height-1) return undefined;
  return pane.rows[pane.offset+y-pane.y-1]?.item;
}
export function canMonitorDiff(frame?: MonitorFrame): boolean {
  return Boolean(frame?.panes.some(p=>p.id==='details'&&p.height>2&&p.width>=40));
}
export function handleMonitorInput(state: MonitorState, input: WorkbenchInput, ctx: MonitorContext): MonitorOutcome {
  let next: MonitorState = {...state,tree:{...state.tree},modes:{...state.modes},scroll:{...state.scroll}};
  let key = input.type==='key'?input.key:'';
  const result = (action?:MonitorOutcome['action'],close=false): MonitorOutcome => ({state:next,close,action});
  if(key==='close') return result(undefined,true);
  if(next.help) { if(['escape','help','enter'].includes(key))next.help=false;return result(); }
  if(input.type==='mouse') {
    const control = input.button==='left'?ctx.frame?.controls.find(c=>input.y===c.y&&input.x>=c.x&&input.x<c.x+c.width):undefined;
    if(control?.kind==='main') return result({type:'switch',id:ctx.tree.rootId});
    if(control?.kind==='settings') return result({type:'settings'});
    if(control?.pane) {
      next.focus=control.pane;
      key=control.kind==='close'?'pane-close':'pane-fold';
    } else {
      const pane=ctx.frame?.panes.find(p=>input.x>=p.x&&input.x<p.x+p.width&&input.y>=p.y&&input.y<p.y+p.height);
      if(!pane) return result();
      next.focus=pane.id;
      if(input.button==='left') {
        if(input.y===pane.y) key='pane-fold';
        else {
          const id=monitorItemAt(pane,input.x,input.y);
          if(!id)return result();
          if(pane.id==='agents') {
            if(!visibleRows(ctx.tree.nodes,next.tree).some(row=>row.node.id===id))return result();
            next.tree.selectedId=id;next.preview='agent';next.scroll.details=0;
            return result({type:'switch',id});
          }
          if(pane.id==='worktrees') {next.selectedWorktree=id;next.preview='worktree';}
          if(pane.id==='changes') {next.selectedFile=id;next.preview='file';}
          next.scroll.details=0;return result();
        }
      } else key=input.button==='wheel-down'?'down':'up';
    }
  }
  if(key==='settings')return result({type:'settings'});
  if(key==='main')return result({type:'switch',id:ctx.tree.rootId});
  if(key==='open-session')return next.focus==='agents'&&next.tree.selectedId?result({type:'switch',id:next.tree.selectedId}):result();
  if(key==='help')next.help=true;
  else if(key==='pane-close') {
    next.modes[next.focus]='closed';next.zoom=false;
    next.focus=MONITOR_PANES.find(id=>next.modes[id]!=='closed')??'agents';
  } else if(key==='pane-fold')next.modes[next.focus]=next.modes[next.focus]==='folded'?'open':'folded';
  else if(MONITOR_PANES.includes(key as MonitorPane))next=openPane(next,key as MonitorPane);
  else if(key==='tab'||key==='shift-tab') {
    const visible=MONITOR_PANES.filter(id=>next.modes[id]!=='closed');
    if(visible.length)next.focus=visible[(visible.indexOf(next.focus)+(key==='tab'?1:visible.length-1))%visible.length];
  } else if(key==='enter'||key==='detail-toggle') {
    const from=next.focus;
    if(from==='agents')next.preview='agent';else if(from==='worktrees')next.preview='worktree';else if(from==='changes')next.preview='file';
    next=openPane(next,'details');next.scroll.details=0;
  } else if(key==='zoom')next.zoom=!next.zoom;
  else if(key==='escape') {
    if(next.zoom)next.zoom=false;
    else if(next.focus==='details'){next.modes.details='closed';next.focus=next.preview==='agent'?'agents':next.preview==='worktree'?'worktrees':'changes';}
    else return result(undefined,true);
  } else {
    const pane=ctx.frame?.panes.find(p=>p.id===next.focus);
    const page=Math.max(1,(pane?.height??5)-2);
    // A two-line worktree card is one item, not two keyboard destinations.
    const visibleItems = pane ? new Set(pane.rows.slice(pane.offset,pane.offset+page).flatMap(row=>row.item ? [row.item] : [])) : new Set<string>();
    const itemPage = visibleItems.size || page;
    const delta=key==='down'?1:key==='up'?-1:key==='page-down'?itemPage:key==='page-up'?-itemPage:0;
    const move=delta!==0||key==='home'||key==='end';
    if(next.focus==='agents') {
      const rows=visibleRows(ctx.tree.nodes,next.tree);
      if(move){const index=rows.findIndex(row=>row.node.id===next.tree.selectedId);const target=key==='home'?0:key==='end'?rows.length-1:Math.max(0,index)+delta;
        const row=rows[Math.max(0,Math.min(rows.length-1,target))];if(row)next.tree.selectedId=row.node.id;
      } else if(key==='sort')next.tree.sort=next.tree.sort==='active'?'created':'active';
      else if(['left','right','filter'].includes(key))next.tree=applyKey(next.tree,key as 'left'|'right'|'filter',rows).state;
    } else if(move) {
      const ids=pane?[...new Set(pane.rows.map(row=>row.item).filter((id):id is string=>id!==undefined))]:[];
      if(ids.length&&(next.focus==='worktrees'||next.focus==='changes')) {
        const current=next.focus==='worktrees'?next.selectedWorktree:next.selectedFile;
        const index=ids.indexOf(current??'');const target=key==='home'?0:key==='end'?ids.length-1:Math.max(0,index)+delta;
        const id=ids[Math.max(0,Math.min(ids.length-1,target))];
        if(next.focus==='worktrees'){next.selectedWorktree=id;next.preview='worktree';}else{next.selectedFile=id;next.preview='file';}
      }else next.scroll[next.focus]=key==='home'?0:key==='end'?Math.max(0,(pane?.contentLength??0)-page):Math.max(0,next.scroll[next.focus]+delta);
    }
  }
  if(next.tree.selectedId!==state.tree.selectedId||next.selectedWorktree!==state.selectedWorktree||next.selectedFile!==state.selectedFile)next.scroll.details=0;
  return result();
}
