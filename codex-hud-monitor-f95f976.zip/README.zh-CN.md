# Codex HUD：默认监控页（基于 f95f976）

## 基线与应用

仓库：CartmanFatass/codex-hud
基线：f95f976097cc255a1b26b7c089cc960991d6eef7（本次通过 GitHub connector 核对的 main）

这是针对该版本的单个补丁，不是继续叠加在 8c3dcc2 上的新一层补丁。
没有修改远端仓库或用户 checkout。不要把 zip 中的源码直接覆盖自己的修改。

在仓库根目录先检查，再应用：

```sh
git apply --check /path/to/codex-hud-monitor-f95f976.patch
git apply /path/to/codex-hud-monitor-f95f976.patch
npm run build
npm test
```

若检查不通过，停止应用并比较本地差异，不要强制覆盖或 checkout。编译成功后可用 F12 关闭再打开树进程；不需要退出工作的主会话。这里没有修改 tmux 绑定。

## 默认页只监控

默认打开：1 Agents、2 Worktrees。
默认关闭：3 Changes、4 Inspector。

Agents 每个 agent 一行：树关系、名称、已观测状态；running 有 turnStartedAt 时显示本轮时长。窄栏优先状态与名字，宽栏才增加模型文本。没有 Task、No task reported、Reply、工具命令、任务百分比或测试成功率。done 指已观察到本轮结束，不代表任务验收成功。

移除默认 Reports/Checks/Tasks 区域。宽度变大也不会自动恢复长文本。旧 workbench renderer 保留供原有代码和测试使用，但 tree-page 改为调用新的纯 monitor renderer/input handler。

面板高度按内容分配，不把两个 agent 拉成一大块空盒子。正常宽度左右保留一列 padding；16/20/30/45/70 列有隔离渲染测试。

## Worktrees 是 Git 数据，不是 agent 文件归属

只显示所选仓库的 `git worktree list --porcelain -z` 和各工作树的 porcelain v2 status：分支、目录身份、changed-file 数、冲突、locked、prunable、bare/detached，以及未知/读取失败/过期状态。宽度足够时显示目录标签；完整路径、HEAD、staged/unstaged/untracked 与 ahead/behind 在显式 Inspector 中查看。

`N mod` 是 changed files 数，包含未跟踪文件。一个文件同时 staged/unstaged 时两类可以重叠，不能求和当文件总数。`?` 不等于干净；`stale` 指上次成功读 status 超过 30 秒；没有 upstream 时 ahead/behind 未知，不伪造 0/0。

仓库发现顺序：

1. 树进程环境的 CODEX_HUD_WORKTREE_ROOT 或设置中的 worktreeRoot；显式配置无效时直接报错，不偷偷换仓库。
2. 没有显式配置时，尝试主会话 session metadata 的 cwd，再尝试 HUD 启动 cwd。

不从 agent 回复、工具命令、文件活动推测路径；不递归扫描目录找一个“像是”项目的仓库。截图内 transcript 提到某路径，并不能证明 HUD 应自动切换监控范围。

从仓库外启动、或希望固定监控仓库时，在现有 `$CODEX_HOME/hud-settings.json` 中合并一项（保留其他设置）：

```json
"worktreeRoot": "/absolute/path/to/your/repository"
```

手动编辑后 F12 关开树进程重新加载。当前 Settings 页面支持面板模式切换，不支持自由文本编辑路径。环境变量只在树进程实际收到它时有效；已存在的 tmux server 可能不会继承启动 shell 的任意新环境变量，优先使用 JSON 设置。

点击 worktree 只选择 Git 观察范围，不切 Codex 会话，不 checkout 分支。可选 Changes/文件预览使用所选工作树的数据，不跟随 agent 归属。窄 Changes 只摘要；文件 diff 只在 Inspector 足够宽时读取。

安全边界：execFile 参数数组、shell:false、每条新 Git 命令 5s/1MiB 上限、禁止 lazy fetch、禁用 clean/process filter；不调用 diff/textconv/external diff 读取监控摘要。可选文件预览沿用原 Git collector 的保护。新 collector 每轮最多探测 4 个 worktree，最多并发 2 个 Git 子进程，列表最多 128 个并显式标出截断；大量工作树不能保证全部实时，超时数据会显示 stale。bare/prunable 不做 status 探测。

## 展开、折叠、关闭是三个状态

`[-]` 或 `-`：folded，只保留标题。
`[x]` 或 `x`：closed，连标题也从布局删除；Tab 跳过。
`1/2/3/4`：重开并 focus 对应逻辑面板。
Settings 可设置 open/folded/closed；运行时关闭/折叠会保存，重开 F12 保留。
关闭所有面板后，Main 行和 Settings 入口仍保留。

旧 details/activity/changes 布尔设置不会自动把旧 Reports/Checks 恢复到默认页；新模式键分别为 agentsPane/worktreesPane/changesPane/detailsPane，旧显示主题、宽度等设置保留。

## 返回 Main 与输入安全

顶端整行是固定 Main 点击区，不随 Agents 滚动、折叠或关闭而消失。树内 m 触发同一路径；键盘仍在 Codex 时，不能把 m 当作全局快捷键，要点击整行，或先 Shift+F12。

箭头/jk 只改变预览选择；点击 agent 或 o 才请求切换。选择标记不是 Codex 当前线程的证明。Enter/v 打开显式 Inspector；它只显示状态和身份/Git 元数据，不是长 transcript。

本补丁没有修改 session-navigation.ts：仍通过原 /subagents、完整 UUID 复核、Enter 前重核以及不重开 picker 的状态机。整行按钮解决命中面积，不代表能够绕过草稿或未知界面。

截图中的 “Viewing sub-agent — direct input is disabled” 不能单凭一行文字当作可安全输入的证明。若原状态机不能识别为空 composer/现有 picker，仍会拒绝发键。没有实机验证该只读子代理界面下的完整往返，也没有声称修复它的全部导航边界。

## 文件

修改 4 个文件：tree-page.ts、settings.ts、render/settings-page.ts、utils/workbench-input.ts。
新增 4 个文件：render/monitor.ts、collectors/worktrees.ts、两个 tests/unit 测试。

compact status、tmux 入口/toggle/paste、session-navigation、session-parent、subagent-tree、panel-state 排序均未改动。测试与补丁核验边界见 TEST_RESULTS.md。
