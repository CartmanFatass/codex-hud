# 实际执行的验证与未执行项

## 基线

GitHub connector 确认 main：f95f976097cc255a1b26b7c089cc960991d6eef7。
四个被修改原文件均按 Git blob SHA 校验，与 connector 返回值一致，见 BASE_MANIFEST.json。
源文件来自 connector 与可核验的前次附件；没有当前完整仓库 checkout。

环境：Node.js v22.16.0、TypeScript 5.8.3、Git 2.47.3（Linux）。

## 已执行

- 两个新增测试文件，共 32 个测试：32 pass，0 fail，0 skipped，0 todo。原始 TAP 在 verification/tests.tap。
- 测试使用新源文件与哈希核对过的实际 colors/palette/hud-config/panel-state/codex-path 实现；没有用假的渲染或排序行为替代它们。
- 新/改 TypeScript 文件执行 transpileModule 语法转译检查，无诊断。此检查不是语义类型检查。
- monitor 测试覆盖：不展示 Task/Reply/Reports/Checks、每 agent 单行、中文/emoji/ANSI/bidi 安全、多个宽高/主题、closed/folded 区别、Tab 跳过关闭面板、关闭全部后仍能 Main/Settings、Main 全行命中根 UUID、边框/空白不能切会话、点击/键盘行为区分、worktree 两行命中同一对象、翻页按逻辑对象、窄 Changes 无隐藏文件选择、冲突优先、invalid date、设置持久化、旧设置与新默认分离。
- worktree 测试覆盖：NUL records、特殊路径、rename 单次计数、staged/unstaged 重叠、冲突、未知 upstream、截断/异常拒绝、路径来源约束、并发/轮询上限、失败清除旧 clean、bare/prunable 跳过、filter 禁用与不可表达配置 fail closed、列表上限、重复收集去重。
- 其中一个测试调用真实 Git：仅在隔离临时目录 git init 并创建一个带换行/tab/ESC 的未跟踪文件，验证 collector 的结果及前后 status 相同。没有 git add、commit、checkout 或 worktree add。
- 在四个已校验原文件的副本上执行整个补丁的 git apply --check 和 git apply，均 exit 0；应用后 8 个文件与 updated 逐字节一致。未创建索引或 commit。日志见 verification/patch-check.txt。
- 实际 renderMonitor 输出保存为 16/20/30/45/70 列文本快照；Git 状态来自合成 fixture，不是用户当前数据。

## 未执行，不据此作成功保证

- 没有完整仓库 npm run build / npm test，也没有完整项目 TypeScript 语义检查。
- 没有真实 tmux/Codex 0.154 操作：F12/Shift+F12、键盘焦点、鼠标、原 /subagents 状态机、只读子代理返回 Main、闪烁等未实机回归。
- 没有新建多个真实 linked worktrees（不做 checkout），多 worktree、冲突、locked/prunable、恶意 filter 等由 parser/collector fixtures 覆盖；不是这些场景全部真实仓库集成通过。
- 没有 Windows/Node 18、真实 partial clone、极大仓库或大量 worktree 的端到端性能验证。
- 没有检查用户本地未提交修改，补丁检查只保证对 f95f976 的已校验文件可应用。

## 在完整 checkout 中应执行

先 git apply --check，不匹配则停止；应用后 npm run build、npm test。新功能的单元测试已放在项目正常 tests/unit 路径；应由项目原 test 脚本编译和执行。

实机重点：默认无 Task/Reply/Checks、全宽 Main、Settings 与 1–4 重开、关闭重开 F12 后模式保留、点击/滚动不改变 Codex 快捷键策略、所选 worktree 范围、draft/copy-mode/未知界面不得强行输入、切换后不重开 picker。不要把上述隔离 32 个测试当成完整 HUD 验收。
